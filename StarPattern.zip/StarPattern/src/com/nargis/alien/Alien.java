package com.nargis.alien;

import java.util.Scanner;

public class Alien {

	int input()
	{
		Scanner sc = new Scanner(System.in);
		int row;

		System.out.println("Enter the row ");
		row = sc.nextInt();

		try {
			if (row % 2 == 0)
				throw new evenException("Please select a odd number to get symmetric pattern");
		} catch (evenException e) {
			System.err.println(e);
		}
		return row;

	}

	void patternTelusko(int row) 
	{
		int n = (row + 1) / 2;

		for (int i = 1; i <= row; i++) 
		{
			// Pattern T
			for (int j = 1; j <= row; j++) 
			{
				if (i == 1 || j == n)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern E
			for (int j = 1; j <= row; j++) 
			{
				if (j == 1 || i == 1 || i == n || i == row)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern L
			for (int j = 1; j <= row; j++) 
			{
				if (j == 1 || i == row)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern U
			for (int j = 1; j <= row; j++) 
			{
				if (j == 1 || j == row || i == row)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern S
			for (int j = 1; j <= row; j++) 
			{

				if (i == 1 || i == n || i == row || i <= n && j == 1 || i >= n && j == row)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern K
			for (int j = 1; j <= n; j++) 
			{
				if (j == 1 || i < n && j == (n + 1) - i || i > n && j == i - (n - 1))

					System.out.print("* ");
				 else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern O
			for (int j = 1; j <= row; j++) 
			{
				if (i == 1 || i == row || j == 1 || j == row)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.println();
		}

	}

	void patternIneuron(int row) {
		int n = (row + 1) / 2;
		int k = 0;

		for (int i = 1; i <= row; i++) 
		{
			// Pattern I
			for (int j = 1; j <= row; j++)
			{
				if (i == 1 || i == row || j == n)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern N
			for (int j = 1; j <= row; j++) 
			{
				if (j == 1 || j == row || (i == j && (j > 0 && j < row)))
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern E
			for (int j = 1; j <= row; j++)
			{
				if (j == 1 || i == 1 || i == n || i == row)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern U
			for (int j = 1; j <= row; j++)
			{
				if (j == 1 || j == row || i == row)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern R
			for (int j = 1; j <= n; j++)
			{

				if (j == 1 || (j == n && (i != 1 && i != n)) || ((i == 1 || i == n) && (j > 0 && j < n)))
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern O
			for (int j = 1; j <= row; j++) 
			{
				if (i == 1 || i == row || j == 1 || j == row)
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.print(" ");
			// Pattern N
			for (int j = 1; j <= row; j++)
			{
				if (j == 1 || j == row || (i == j && (j > 0 && j < row)))
					System.out.print("* ");
				else
					System.out.print("  ");
			}

			System.out.println();
		}

	}

}