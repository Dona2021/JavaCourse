package com.nargis.alien;



public class Main 
{
	public static void main(String[] args) 
	{
		Alien telusko=new Alien();
		int row1=telusko.input();
		
		telusko.patternTelusko(row1);

		
		Alien ineuron=new Alien();
		int row2=ineuron.input();
		ineuron.patternIneuron(row2);
		
		
		
	}
}
