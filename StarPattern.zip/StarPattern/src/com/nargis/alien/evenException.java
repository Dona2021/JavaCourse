package com.nargis.alien;

public class evenException extends Exception
{
	evenException(String str)
	{
		super(str);
	}
}
